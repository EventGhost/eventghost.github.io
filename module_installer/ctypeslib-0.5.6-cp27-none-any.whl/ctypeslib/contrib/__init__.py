# ctypeslib.contrib contains contributed code that does not yet
# fit elsewhere.
