ctypeslib contains these packages:

 - ``ctypeslib.codegen``       - a code generator

 - ``ctypeslib.contrib``       - various contributed modules

 - ``ctypeslib.util``          - assorted small helper functions

 - ``ctypeslib.test``          - unittests

There is not yet an official release, but ctypeslib can be installed
directly from the subversion repository with::

    easy_install ctypeslib==dev

The SVN repository is here:

http://svn.python.org/projects/ctypes/trunk/ctypeslib/#egg=ctypeslib-dev



