#!python
import sys
from ctypeslib.h2xml import main

if __name__ == "__main__":
    sys.exit(main())
