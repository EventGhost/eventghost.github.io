# Copyright 2012-2016 Jonathan Paugh and contributors
# See COPYING for license details
from functools import partial, update_wrapper
from agithub.base import VERSION, STR_VERSION

__all__ = [ "VERSION", "STR_VERSION" ]
